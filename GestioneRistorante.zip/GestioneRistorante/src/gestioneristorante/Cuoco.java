/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestioneristorante;

import java.util.Random;

/**
 *
 * @author domenicodimarino
 */
public class Cuoco implements Runnable{

    private Comande comande;

    public Cuoco(Comande comande) {
        this.comande = comande;
    }
    
    
    @Override
    public void run() {
        
        Random n = new Random(7393);
        
        
        while(!Thread.currentThread().isInterrupted()){
            try {
                Ordinazione o = comande.consegnaOrdinazione();
                
                Thread.sleep(5000); //delay min
                Thread.sleep(n.nextInt(6)*1000); //delay max
                
                System.out.println("Piatto pronto: " + o.toString());
            } catch (InterruptedException ex) {
                return;
            }
        }
    }
    
}
