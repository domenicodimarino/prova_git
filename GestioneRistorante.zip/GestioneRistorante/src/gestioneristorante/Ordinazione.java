/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestioneristorante;

/**
 *
 * @author domenicodimarino
 */
public class Ordinazione {
    private String piatto;
    private int tavolo;
    private int quantita;
    
    public Ordinazione(String piatto, int tavolo, int quantita){
        this.piatto = piatto;
        this.tavolo = tavolo;
        this.quantita = quantita;
    }

    public String getPiatto() {
        return piatto;
    }

    public void setPiatto(String piatto) {
        this.piatto = piatto;
    }

    public int getTavolo() {
        return tavolo;
    }

    public void setTavolo(int tavolo) {
        this.tavolo = tavolo;
    }

    public int getQuantita() {
        return quantita;
    }

    public void setQuantita(int quantita) {
        this.quantita = quantita;
    }

    @Override
    public String toString() {
        return "Piatto: " + piatto + ", Tavolo: " + tavolo + ", Quantita: " + quantita;
    }
    
}
