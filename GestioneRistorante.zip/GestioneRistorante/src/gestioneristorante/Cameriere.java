package gestioneristorante;

import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author domenicodimarino
 */
public class Cameriere implements Runnable {

    private String nome;
    private Comande comande;
    private Menu menu;

    public Cameriere(String nome, Comande comande) {
        this.nome = nome;
        this.comande = comande;
        this.menu = new Menu();
    }
    
    
    
    @Override
    public void run() {
        Random n1 = new Random(2300); //generatore numero tavolo
        Random n2 = new Random(6782); //generatore quantita
        
        while(!Thread.currentThread().isInterrupted()){
            try {
                Ordinazione o = new Ordinazione(menu.getPiatto(),(n1.nextInt(5)+1),(n2.nextInt(4)+1));
                
                Thread.sleep(5000); //delay min
                Thread.sleep(n1.nextInt(6)*1000); //delay max
                
                comande.aggiungiOrdinazione(o);
                
 
                System.out.println("Ordinazione presa da: " + this.nome + " " + o.toString());
            } catch (InterruptedException ex) {
                return;
            }
        }
    }
    
}
