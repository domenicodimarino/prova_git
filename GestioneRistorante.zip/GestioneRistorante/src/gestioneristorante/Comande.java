/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestioneristorante;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.LinkedList;

/**
 *
 * @author domenicodimarino
 */
public class Comande implements Serializable{
    
    private LinkedList<Ordinazione> comande;
    private String filename;
    public Comande(String filename, Boolean leggiBackup){
        this.filename = filename;
        comande = new LinkedList<>();
        
        if(leggiBackup){
            try(ObjectInputStream i = new ObjectInputStream(new BufferedInputStream(new FileInputStream(this.filename)))){
            comande = (LinkedList<Ordinazione>)i.readObject();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        }
        
    }
    public synchronized void aggiungiOrdinazione(Ordinazione ordinazione){
        comande.add(ordinazione);
        notifyAll();
    }
    public synchronized Ordinazione consegnaOrdinazione() throws InterruptedException{
        while(comande.isEmpty())
            wait();
        
        notifyAll();
        return comande.remove();
    }
    public synchronized void salvaOrdinazioni() throws InterruptedException{
        while(comande.isEmpty())
            wait();
        
        int i = 0;
        while(i < comande.size()){
            try(ObjectOutputStream o = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(this.filename)))){
            o.writeObject(comande.get(i).toString());
            }catch(IOException e){
            System.out.println(e.getMessage());
            }
            i++;
        }
        
    }
}
